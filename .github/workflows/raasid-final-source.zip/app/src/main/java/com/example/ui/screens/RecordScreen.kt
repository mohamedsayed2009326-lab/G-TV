package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CarCrash
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RecordedPlate
import com.example.ui.PlateViewModel
import com.example.ui.components.MatchAlertBanner
import com.example.ui.components.PlateCardItem
import com.example.ui.components.PlateInputCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.SuccessGreen

@Composable
fun RecordScreen(
    viewModel: PlateViewModel,
    modifier: Modifier = Modifier
) {
    val selectedType by viewModel.selectedVehicleType.collectAsState()
    val manualInput by viewModel.manualPlateInput.collectAsState()
    val isGettingLocation by viewModel.isGettingLocation.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val matchedAlertPlate by viewModel.matchedAlertPlate.collectAsState()
    val lastSpeechInfo by viewModel.lastSpeechInfo.collectAsState()
    val recentPlates by viewModel.recentPlates.collectAsState()

    val totalRecorded by viewModel.recordedCount.collectAsState()
    val totalMatched by viewModel.matchedCount.collectAsState()
    val totalWatchlist by viewModel.watchlistCount.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Dashboard KPI Stat Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "المرصودة",
                    value = totalRecorded.toString(),
                    icon = Icons.Default.Radar,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "مطابقات",
                    value = totalMatched.toString(),
                    icon = Icons.Default.Warning,
                    color = AlertRed,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "قائمة المراقبة",
                    value = totalWatchlist.toString(),
                    icon = Icons.Default.ListAlt,
                    color = Color(0xFF028090),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Match Alert Banner if plate matched!
        if (matchedAlertPlate != null) {
            item {
                MatchAlertBanner(
                    matchedPlate = matchedAlertPlate,
                    onDismiss = { viewModel.dismissMatchAlert() }
                )
            }
        }

        // Voice & Manual Input Card
        item {
            PlateInputCard(
                selectedType = selectedType,
                onSelectType = { viewModel.selectVehicleType(it) },
                manualInput = manualInput,
                onManualInputChange = { viewModel.setManualPlateInput(it) },
                onSubmitManual = { viewModel.submitManualPlate() },
                onVoiceResult = { viewModel.processVoiceInput(it) },
                lastSpeechInfo = lastSpeechInfo,
                isGettingLocation = isGettingLocation,
                isListening = isListening,
                onListeningChanged = { viewModel.setListeningState(it) }
            )
        }

        // Recent Scans Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "آخر اللوحات المرصودة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (recentPlates.isNotEmpty()) {
                    Text(
                        text = "(${recentPlates.size})",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (recentPlates.isEmpty()) {
            item {
                EmptyRecentState()
            }
        } else {
            items(recentPlates, key = { it.id }) { plate ->
                PlateCardItem(
                    plate = plate,
                    onDelete = { viewModel.deleteRecordedPlate(it) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.08f)
        ),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmptyRecentState() {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Radar,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "لا توجد لوحات مرصودة بعد",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "اضغط على زر الميكروفون بالأعلى وتحدث برقم اللوحة ونوع المركبة لتسجيلها فورياً مع موقعها الجغرافي.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.padding(top = 4.dp),
                lineHeight = 18.sp
            )
        }
    }
}
