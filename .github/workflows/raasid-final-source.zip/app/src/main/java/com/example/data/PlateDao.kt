package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlateDao {

    // Recorded Plates
    @Query("SELECT * FROM recorded_plates ORDER BY timestamp DESC")
    fun getAllRecordedPlates(): Flow<List<RecordedPlate>>

    @Query("SELECT * FROM recorded_plates ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentRecordedPlates(limit: Int = 10): Flow<List<RecordedPlate>>

    @Query("SELECT * FROM recorded_plates WHERE vehicleType = :type ORDER BY timestamp DESC")
    fun getRecordedPlatesByType(type: String): Flow<List<RecordedPlate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecordedPlate(plate: RecordedPlate): Long

    @Update
    suspend fun updateRecordedPlate(plate: RecordedPlate)

    @Delete
    suspend fun deleteRecordedPlate(plate: RecordedPlate)

    @Query("DELETE FROM recorded_plates")
    suspend fun deleteAllRecordedPlates()

    @Query("SELECT COUNT(*) FROM recorded_plates")
    fun getRecordedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM recorded_plates WHERE isMatched = 1")
    fun getMatchedCount(): Flow<Int>

    // Watchlist Plates
    @Query("SELECT * FROM watchlist_plates ORDER BY dateAdded DESC")
    fun getAllWatchlistPlates(): Flow<List<WatchlistPlate>>

    @Query("SELECT * FROM watchlist_plates")
    suspend fun getWatchlistSync(): List<WatchlistPlate>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchlistPlates(plates: List<WatchlistPlate>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchlistPlate(plate: WatchlistPlate): Long

    @Delete
    suspend fun deleteWatchlistPlate(plate: WatchlistPlate)

    @Query("DELETE FROM watchlist_plates")
    suspend fun clearWatchlist()

    @Query("SELECT COUNT(*) FROM watchlist_plates")
    fun getWatchlistCount(): Flow<Int>
}
