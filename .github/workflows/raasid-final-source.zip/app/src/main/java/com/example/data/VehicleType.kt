package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.RvHookup
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class VehicleType(
    val id: String,
    val arabicName: String,
    val englishName: String,
    val color: Color,
    val icon: ImageVector,
    val keywords: List<String>
) {
    PICKUP(
        id = "pickup",
        arabicName = "ونيت",
        englishName = "Pickup",
        color = Color(0xFFD97706), // Amber 600
        icon = Icons.Default.RvHookup,
        keywords = listOf("ونيت", "وانيت", "دبابة", "دبابه", "بيك اب", "بيك أب", "نص نقل", "نصف نقل", "هايلكس", "ديماكس", "pickup")
    ),
    TAXI(
        id = "taxi",
        arabicName = "تاكسي",
        englishName = "Taxi",
        color = Color(0xFFCA8A04), // Yellow 600
        icon = Icons.Default.LocalTaxi,
        keywords = listOf("تاكسي", "تكسي", "اجرة", "أجرة", "ليموزين", "taxi")
    ),
    MICROBUS(
        id = "microbus",
        arabicName = "ميكروباص",
        englishName = "Microbus",
        color = Color(0xFF2563EB), // Blue 600
        icon = Icons.Default.DirectionsBus,
        keywords = listOf("ميكروباص", "ميكروباس", "مكرباص", "مكرباس", "باص", "سرفيس", "مشروع", "فان", "ميني باص", "ميني", "microbus")
    ),
    TRUCK(
        id = "truck",
        arabicName = "نقل",
        englishName = "Truck",
        color = Color(0xFF7C3AED), // Purple 600
        icon = Icons.Default.LocalShipping,
        keywords = listOf("نقل", "شاحنة", "شاحنه", "تريلا", "تريله", "لوري", "جامبو", "جرار", "مقطورة", "مقطوره", "نقل ثقيل", "truck")
    ),
    PRIVATE(
        id = "private",
        arabicName = "ملاكي",
        englishName = "Private Car",
        color = Color(0xFF059669), // Emerald 600
        icon = Icons.Default.DirectionsCar,
        keywords = listOf("ملاكي", "خصوصي", "خاصة", "خاصه", "صالون", "عربية ملاكي", "سيارة ملاكي")
    ),
    OTHER(
        id = "other",
        arabicName = "أخرى",
        englishName = "Other",
        color = Color(0xFF6B7280), // Gray 500
        icon = Icons.Default.MoreHoriz,
        keywords = listOf("أخرى", "اخرى", "مختلف")
    );

    companion object {
        private val fillerWords = setOf(
            "نوعها", "نوعه", "نوع",
            "عربية", "عربيه", "سيارة", "سياره", "مركبة", "مركبه",
            "لوحة", "لوحه", "رقم", "نمرة", "نمره",
            "نمرتها", "لوحتها", "ارقام", "أرقام", "حروف"
        )

        fun fromId(id: String?): VehicleType {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: OTHER
        }

        fun fromArabicName(name: String?): VehicleType {
            if (name.isNullOrBlank()) return OTHER
            val cleaned = name.trim().lowercase()
            return entries.firstOrNull { type ->
                type.arabicName.equals(cleaned, ignoreCase = true) ||
                        type.keywords.any { cleaned.contains(it) }
            } ?: OTHER
        }

        /**
         * Detects vehicle type spoken by voice:
         * Works whether the user says the type first ("ونيت 123"), in the middle ("لوحة تاكسي 456"),
         * or last ("123 ميكروباص").
         * Strips common speech fillers ("نوع", "عربية", "لوحة", "رقم") and converts number words.
         */
        fun extractFromSpeech(spokenText: String): Pair<VehicleType?, String> {
            val convertedText = PlateNormalizer.convertSpokenWordsToDigits(spokenText.trim())
            var detectedType: VehicleType? = null

            // First check multi-word keywords (e.g. "بيك اب", "نص نقل", "عربية ملاكي")
            var text = convertedText
            for (type in entries) {
                for (keyword in type.keywords) {
                    if (keyword.contains(" ") && text.contains(keyword, ignoreCase = true)) {
                        detectedType = type
                        text = text.replace(keyword, " ")
                        break
                    }
                }
                if (detectedType != null) break
            }

            // Split into tokens
            val tokens = text.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }
            val remainingTokens = mutableListOf<String>()

            for (token in tokens) {
                // If we haven't found a type yet, check if this token matches a single-word keyword
                if (detectedType == null) {
                    val matchingType = entries.firstOrNull { type ->
                        type.keywords.any { it.equals(token, ignoreCase = true) }
                    }
                    if (matchingType != null) {
                        detectedType = matchingType
                        continue
                    }
                } else {
                    // If we already detected the type, still discard any redundant keyword tokens
                    val isKeyword = entries.any { type ->
                        type.keywords.any { it.equals(token, ignoreCase = true) }
                    }
                    if (isKeyword) continue
                }

                // Discard filler words (نوع، عربية، لوحة...)
                if (token in fillerWords) {
                    continue
                }

                remainingTokens.add(token)
            }

            val finalPlate = remainingTokens.joinToString(" ").trim()
            return Pair(detectedType, finalPlate)
        }
    }
}
