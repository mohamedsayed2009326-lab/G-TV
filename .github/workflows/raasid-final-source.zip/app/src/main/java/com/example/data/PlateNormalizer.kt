package com.example.data

object PlateNormalizer {

    private val numberWordsMap = mapOf(
        "صفر" to "0",
        "واحد" to "1",
        "واحدة" to "1",
        "اثنان" to "2",
        "اثنين" to "2",
        "إثنين" to "2",
        "اتنين" to "2",
        "ثلاثة" to "3",
        "تلاتة" to "3",
        "أربعة" to "4",
        "اربعة" to "4",
        "خمسة" to "5",
        "ستة" to "6",
        "سبعة" to "7",
        "ثمانية" to "8",
        "تمانية" to "8",
        "تسعة" to "9",
        "عشرة" to "10"
    )

    /**
     * Converts spoken Arabic number words (e.g. واحد، اتنين، تلاتة) to digits (1, 2, 3)
     */
    fun convertSpokenWordsToDigits(input: String): String {
        if (input.isBlank()) return ""
        return input.trim().split("\\s+".toRegex()).joinToString(" ") { token ->
            numberWordsMap[token] ?: numberWordsMap[token.replace("[،,]".toRegex(), "")] ?: token
        }
    }

    /**
     * Converts Eastern Arabic digits (٠١٢٣٤٥٦٧٨٩) to standard ASCII digits (0123456789)
     */
    fun convertArabicDigitsToAscii(input: String): String {
        val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        var result = input
        for (i in arabicDigits.indices) {
            result = result.replace(arabicDigits[i], (i + '0'.code).toChar())
        }
        return result
    }

    /**
     * Converts standard ASCII digits (0123456789) to Eastern Arabic digits (٠١٢٣٤٥٦٧٨٩)
     */
    fun convertAsciiToArabicDigits(input: String): String {
        val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        var result = input
        for (i in 0..9) {
            result = result.replace((i + '0'.code).toChar(), arabicDigits[i])
        }
        return result
    }

    /**
     * Formats plate according to standard rule:
     * 4 digits and 3 letters.
     * If 3 digits are spoken/entered, prepends '0' to make it 4 digits (e.g. "123" -> "0123").
     */
    fun formatStandardPlate(rawPlate: String): String {
        if (rawPlate.isBlank()) return ""
        val digitsConverted = convertSpokenWordsToDigits(rawPlate)
        val ascii = convertArabicDigitsToAscii(digitsConverted)

        val digits = StringBuilder()
        val letters = mutableListOf<Char>()

        for (ch in ascii) {
            if (ch.isDigit()) {
                digits.append(ch)
            } else if (ch.isLetter()) {
                letters.add(ch)
            }
        }

        val rawDigitsStr = digits.toString()
        val formattedDigits = when {
            rawDigitsStr.length == 3 -> "0$rawDigitsStr" // Prepend 0 if exactly 3 digits
            rawDigitsStr.length == 4 -> rawDigitsStr
            rawDigitsStr.length > 4 -> rawDigitsStr.take(4)
            rawDigitsStr.isNotEmpty() -> rawDigitsStr.padStart(4, '0')
            else -> ""
        }

        // Format letters with spaces: e.g. "أ ب ج"
        val formattedLetters = letters.joinToString(" ")

        return when {
            formattedDigits.isNotEmpty() && formattedLetters.isNotEmpty() -> "$formattedDigits $formattedLetters"
            formattedDigits.isNotEmpty() -> formattedDigits
            formattedLetters.isNotEmpty() -> formattedLetters
            else -> rawPlate.trim()
        }
    }

    /**
     * Normalizes a license plate for strict or semi-fuzzy comparison:
     * - Applies the 4-digits rule (prepends 0 if 3 digits)
     * - Converts Arabic digits to ASCII digits
     * - Normalizes Arabic letters (أ/إ/آ -> ا, ة -> ه, ى -> ي)
     * - Removes all whitespace and punctuation
     */
    fun normalize(rawPlate: String): String {
        if (rawPlate.isBlank()) return ""
        val standard = formatStandardPlate(rawPlate)
        val asciiDigits = convertArabicDigitsToAscii(standard)
        return asciiDigits
            .replace("[\\s\\-_.,/\\\\]".toRegex(), "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .uppercase()
    }

    fun formatDisplay(rawPlate: String): String {
        val standard = formatStandardPlate(rawPlate)
        return standard.ifBlank { rawPlate.trim().replace("\\s+".toRegex(), " ") }
    }

    /**
     * Compares two plates for match:
     * Handles matching with or without leading zero, so "123 أ ب ج" and "0123 أ ب ج" match 100%.
     */
    fun isMatch(plateA: String, plateB: String): Boolean {
        val normA = normalize(plateA)
        val normB = normalize(plateB)
        if (normA.isEmpty() || normB.isEmpty()) return false

        if (normA == normB) return true

        // Match ignoring leading zero (e.g. 0123ابج matches 123ابج)
        val noZeroA = normA.removePrefix("0")
        val noZeroB = normB.removePrefix("0")
        if (noZeroA.isNotEmpty() && noZeroA == noZeroB) return true

        return normA.contains(normB) || normB.contains(normA) ||
                (noZeroA.isNotEmpty() && noZeroB.isNotEmpty() && (noZeroA.contains(noZeroB) || noZeroB.contains(noZeroA)))
    }
}
