package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.LocationService
import com.example.data.LocationData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

private data class StreetEntry(
    val id: String,
    val name: String,
    val neighborhood: String,
    val startLat: Double?, val startLon: Double?, val startAddress: String?,
    val endLat: Double?, val endLon: Double?, val endAddress: String?,
    val audioPath: String?, val transcript: String = "", val plates: String = "", val ended: Boolean = false
)

@Composable
fun StreetsScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("street_radar", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val locationService = remember { LocationService(context) }
    val entries = remember { mutableStateListOf<StreetEntry>().apply { addAll(loadEntries(prefs)) } }
    var streetName by remember { mutableStateOf("") }
    var neighborhood by remember { mutableStateOf("") }
    var geminiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var deepgramKey by remember { mutableStateOf(prefs.getString("deepgram_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var activeId by remember { mutableStateOf<String?>(entries.firstOrNull { !it.ended }?.id) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recording by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("أدخل اسم الشارع والحي، ثم ابدأ التسجيل.") }
    var permissionGranted by remember { mutableStateOf(
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    ) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        val audioOk = results[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val fineOk = results[Manifest.permission.ACCESS_FINE_LOCATION] == true || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseOk = results[Manifest.permission.ACCESS_COARSE_LOCATION] == true || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        permissionGranted = audioOk && (fineOk || coarseOk)
        if (!permissionGranted) status = "يجب السماح بالميكروفون والموقع لتسجيل الشوارع."
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            val parts = spoken.split(" حي ", limit = 2)
            streetName = parts[0].trim()
            if (parts.size > 1) neighborhood = parts[1].trim()
        }
    }

    fun saveAll() { saveEntries(prefs, entries) }
    suspend fun currentLocation(): LocationData? = locationService.getCurrentLocation()
    fun openMap(lat: Double?, lon: Double?, label: String) {
        if (lat == null || lon == null) { status = "لا توجد إحداثيات محفوظة لهذا الشارع."; return }
        val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon(" + Uri.encode(label) + ")")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
    fun startStreet() {
        if (streetName.isBlank()) { status = "اكتب اسم الشارع أو استخدم زر الإملاء الصوتي أولاً."; return }
        if (!permissionGranted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)); return
        }
        scope.launch {
            try {
                val start = currentLocation()
                val audio = File(context.filesDir, "street_${System.currentTimeMillis()}.m4a")
                val r = createMediaRecorder(context)
                r.setAudioSource(MediaRecorder.AudioSource.MIC)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(96000)
                r.setAudioSamplingRate(44100)
                r.setOutputFile(audio.absolutePath)
                r.prepare(); r.start()
                recorder = r; recording = true
                val entry = StreetEntry(
                    id = System.currentTimeMillis().toString(), name = streetName.trim(), neighborhood = neighborhood.trim(),
                    startLat = start?.latitude, startLon = start?.longitude, startAddress = start?.address,
                    endLat = null, endLon = null, endAddress = null, audioPath = audio.absolutePath
                )
                entries.add(0, entry); activeId = entry.id; saveAll()
                status = "جاري تسجيل: ${entry.name}. عند الانتقال اضغط إيقاف الشارع لحفظ نقطة النهاية."
            } catch (e: Exception) { recording = false; status = "تعذر بدء التسجيل: ${e.localizedMessage ?: "تحقق من أذونات الميكروفون"}" }
        }
    }
    fun stopStreet(endSession: Boolean) {
        scope.launch {
            val id = activeId
            val wasRecording = recording
            if (wasRecording) {
                try { recorder?.stop() } catch (_: Exception) { }
                try { recorder?.release() } catch (_: Exception) { }
            }
            recorder = null; recording = false
            val end = if (id != null) currentLocation() else null
            val index = entries.indexOfFirst { it.id == id }
            if (index >= 0) {
                entries[index] = entries[index].copy(endLat = end?.latitude, endLon = end?.longitude, endAddress = end?.address, ended = endSession)
            }
            if (endSession) {
                for (i in entries.indices) if (!entries[i].ended) entries[i] = entries[i].copy(ended = true)
            }
            saveAll()
            activeId = null
            status = if (endSession) "تم إنهاء الجولة وحفظ الشوارع." else "تم إيقاف الشارع وحفظ نقطة النهاية. أدخل اسم الشارع التالي وابدأه."
        }
    }
    fun transcribeAndAnalyze(entry: StreetEntry) {
        if (deepgramKey.isBlank()) { showSettings = true; status = "أدخل مفتاح Deepgram من الإعدادات أولاً."; return }
        if (geminiKey.isBlank()) { showSettings = true; status = "أدخل مفتاح Gemini من الإعدادات أولاً."; return }
        val path = entry.audioPath
        if (path.isNullOrBlank() || !File(path).exists()) { status = "ملف الصوت غير موجود على الجهاز."; return }
        busyId = entry.id
        scope.launch {
            try {
                val transcript = withContext(Dispatchers.IO) { transcribeDeepgram(File(path), deepgramKey) }
                val plates = withContext(Dispatchers.IO) { extractPlatesWithGemini(transcript, geminiKey) }
                val index = entries.indexOfFirst { it.id == entry.id }
                if (index >= 0) { entries[index] = entries[index].copy(transcript = transcript, plates = plates); saveAll() }
                status = "اكتمل التفريغ والتحليل للشارع ${entry.name}. راجع اللوحات المستخرجة." 
            } catch (e: Exception) { status = "فشل التفريغ أو التحليل: ${e.message ?: "تحقق من الإنترنت والمفاتيح"}" }
            finally { busyId = null }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            try { recorder?.stop() } catch (_: Exception) { }
            try { recorder?.release() } catch (_: Exception) { }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("تسجيل الشوارع", style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, contentDescription = "إعدادات API") }
        }
        OutlinedTextField(value = streetName, onValueChange = { streetName = it }, label = { Text("اسم الشارع (مثال: الشزري 1)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = neighborhood, onValueChange = { neighborhood = it }, label = { Text("الحي (مثال: حي الرمال)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "قل اسم الشارع والحي، مثال: الشزري 1 حي الرمال")
                }
                try { speechLauncher.launch(intent) } catch (_: Exception) { status = "الإملاء الصوتي غير متاح على هذا الجهاز." }
            }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Mic, null); Text("اسم الشارع بالصوت") }
            Button(onClick = { startStreet() }, enabled = !recording, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PlayCircle, null); Text("بدء الشارع")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { stopStreet(false) }, enabled = recording, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PauseCircle, null); Text("إيقاف الشارع") }
            Button(onClick = { stopStreet(true) }, enabled = recording || entries.any { !it.ended }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.StopCircle, null); Text("إنهاء الجولة") }
        }
        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
            Text(status, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
        }
        Divider()
        Text("الشوارع المسجلة", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries, key = { it.id }) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { openMap(entry.startLat, entry.startLon, "${entry.name} ${entry.neighborhood}") }) {
                                Text(entry.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                Text(entry.neighborhood.ifBlank { "الحي غير محدد" }, style = MaterialTheme.typography.bodySmall)
                                Text(if (entry.ended) "انتهى التسجيل" else "جارٍ/غير مكتمل", style = MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick = { openMap(entry.startLat, entry.startLon, "${entry.name} ${entry.neighborhood}") }) { Icon(Icons.Default.Navigation, contentDescription = "فتح الموقع") }
                        }
                        Text("البداية: ${entry.startAddress ?: coords(entry.startLat, entry.startLon)}", style = MaterialTheme.typography.bodySmall)
                        Text("النهاية: ${entry.endAddress ?: coords(entry.endLat, entry.endLon)}", style = MaterialTheme.typography.bodySmall)
                        if (entry.transcript.isNotBlank()) {
                            Text("النص المستخرج:", style = MaterialTheme.typography.labelLarge)
                            Text(entry.transcript, style = MaterialTheme.typography.bodySmall)
                        }
                        if (entry.plates.isNotBlank()) {
                            Text("اللوحات التي حللها Gemini:", style = MaterialTheme.typography.labelLarge)
                            Text(entry.plates, style = MaterialTheme.typography.bodyMedium)
                        }
                        Button(onClick = { transcribeAndAnalyze(entry) }, enabled = busyId == null && !recording) {
                            Icon(Icons.Default.Mic, null); Text(if (busyId == entry.id) "جاري التفريغ والتحليل..." else "تفريغ الصوت وتحليل اللوحات")
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("إعدادات الذكاء الاصطناعي") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أدخل مفاتيحك هنا. تحفظ محليًا على هذا الجهاز.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, label = { Text("Gemini API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                OutlinedTextField(value = deepgramKey, onValueChange = { deepgramKey = it }, label = { Text("Deepgram API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            }
        }, confirmButton = { TextButton(onClick = { prefs.edit().putString("gemini_key", geminiKey.trim()).putString("deepgram_key", deepgramKey.trim()).apply(); showSettings = false; status = "تم حفظ إعدادات المفاتيح على الجهاز." }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("إلغاء") } })
    }
}

private fun coords(lat: Double?, lon: Double?): String = if (lat != null && lon != null) "$lat, $lon" else "غير متاح"

private fun loadEntries(prefs: android.content.SharedPreferences): List<StreetEntry> = try {
    val array = JSONArray(prefs.getString("streets", "[]"))
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i)
        fun dbl(k: String): Double? = if (o.isNull(k)) null else o.optDouble(k).takeIf { it.isFinite() }
        StreetEntry(o.optString("id"), o.optString("name"), o.optString("neighborhood"), dbl("startLat"), dbl("startLon"), o.optString("startAddress").takeIf { it.isNotBlank() }, dbl("endLat"), dbl("endLon"), o.optString("endAddress").takeIf { it.isNotBlank() }, o.optString("audioPath").takeIf { it.isNotBlank() }, o.optString("transcript"), o.optString("plates"), o.optBoolean("ended"))
    }
} catch (_: Exception) { emptyList() }

private fun saveEntries(prefs: android.content.SharedPreferences, entries: List<StreetEntry>) {
    val array = JSONArray()
    entries.forEach { e ->
        array.put(JSONObject().apply {
            put("id", e.id); put("name", e.name); put("neighborhood", e.neighborhood)
            put("startLat", e.startLat ?: JSONObject.NULL); put("startLon", e.startLon ?: JSONObject.NULL); put("startAddress", e.startAddress ?: "")
            put("endLat", e.endLat ?: JSONObject.NULL); put("endLon", e.endLon ?: JSONObject.NULL); put("endAddress", e.endAddress ?: "")
            put("audioPath", e.audioPath ?: ""); put("transcript", e.transcript); put("plates", e.plates); put("ended", e.ended)
        })
    }
    prefs.edit().putString("streets", array.toString()).apply()
}

private fun transcribeDeepgram(file: File, key: String): String {
    val client = OkHttpClient.Builder().callTimeout(180, TimeUnit.SECONDS).build()
    val body = file.readBytes().toRequestBody("audio/mp4".toMediaType())
    val request = Request.Builder().url("https://api.deepgram.com/v1/listen?model=nova-3&language=ar&smart_format=true&punctuate=true")
        .addHeader("Authorization", "Token $key").addHeader("Content-Type", "audio/mp4").post(body).build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Deepgram ${response.code}: ${raw.take(250)}")
        val json = JSONObject(raw)
        val alternatives = json.optJSONObject("results")?.optJSONArray("channels")?.optJSONObject(0)?.optJSONArray("alternatives")
        return alternatives?.optJSONObject(0)?.optString("transcript")?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("لم يرجع Deepgram نصًا")
    }
}

private fun extractPlatesWithGemini(transcript: String, key: String): String {
    val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
    val prompt = "حلل النص العربي التالي المستخرج من تسجيل رصد مركبات. استخرج اللوحات فقط كما وردت، ولا تخترع أرقامًا أو حروفًا. اكتب كل لوحة في سطر، وأضف ملاحظة [غير مؤكدة] عند وجود التباس. إذا لم توجد لوحة واضحة اكتب: لم أتمكن من تحديد لوحة مؤكدة. النص: $transcript"
    val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        .put("generationConfig", JSONObject().put("temperature", 0.1)).toString().toRequestBody("application/json".toMediaType())
    val request = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key").post(body).build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Gemini ${response.code}: ${raw.take(250)}")
        val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        return parts?.optJSONObject(0)?.optString("text")?.trim()?.takeIf { it.isNotBlank() } ?: "لم يتم العثور على لوحات واضحة."
    }
}

@Suppress("DEPRECATION")
private fun createMediaRecorder(context: Context): MediaRecorder =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else MediaRecorder()
