package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recorded_plates")
data class RecordedPlate(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plateNumber: String,
    val normalizedPlate: String,
    val vehicleType: String, // from VehicleType.id
    val timestamp: Long = System.currentTimeMillis(),
    val latitude: Double? = null,
    val longitude: Double? = null,
    val address: String? = null,
    val isMatched: Boolean = false,
    val matchedTargetPlate: String? = null,
    val matchedReason: String? = null,
    val rawSpeechText: String? = null,
    val notes: String = ""
)
