package com.example

import com.example.data.PlateNormalizer
import com.example.data.VehicleType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPlateFormattingThreeDigitsPrependZero() {
        // If 3 digits are spoken, 0 must be prepended at the start
        val plate3 = "123 أ ب ج"
        val formatted3 = PlateNormalizer.formatStandardPlate(plate3)
        assertEquals("0123 أ ب ج", formatted3)

        val spokenArabic3 = "١٢٣ أ ب ج"
        val formattedArabic3 = PlateNormalizer.formatStandardPlate(spokenArabic3)
        assertEquals("0123 أ ب ج", formattedArabic3)

        // Spoken words: واحد اتنين تلاتة
        val spokenWords3 = "واحد اتنين تلاتة أ ب ج"
        val formattedWords3 = PlateNormalizer.formatStandardPlate(spokenWords3)
        assertEquals("0123 أ ب ج", formattedWords3)
    }

    @Test
    fun testPlateFormattingFourDigitsKept() {
        val plate4 = "1234 أ ب ج"
        val formatted4 = PlateNormalizer.formatStandardPlate(plate4)
        assertEquals("1234 أ ب ج", formatted4)
    }

    @Test
    fun testPlateMatchingWithAndWithoutLeadingZero() {
        // Spoken plate (becomes 0123 with 0 prepended) must match Excel plate having 123
        val spokenPadded = "0123 أ ب ج"
        val excelUnpadded = "123 أ ب ج"
        assertTrue(PlateNormalizer.isMatch(spokenPadded, excelUnpadded))
        assertTrue(PlateNormalizer.isMatch(excelUnpadded, spokenPadded))
    }

    @Test
    fun testVehicleTypeSpeechExtraction() {
        val spoken = "ونيت 123 أ ب ج"
        val (type, plate) = VehicleType.extractFromSpeech(spoken)
        assertEquals(VehicleType.PICKUP, type)
        assertEquals("123 أ ب ج", plate)

        val spokenTaxi = "تاكسي 456 د ه و"
        val (typeTaxi, plateTaxi) = VehicleType.extractFromSpeech(spokenTaxi)
        assertEquals(VehicleType.TAXI, typeTaxi)
        assertEquals("456 د ه و", plateTaxi)

        val spokenMicrobus = "ميكروباص 789 س ص ع"
        val (typeMicrobus, plateMicrobus) = VehicleType.extractFromSpeech(spokenMicrobus)
        assertEquals(VehicleType.MICROBUS, typeMicrobus)
        assertEquals("789 س ص ع", plateMicrobus)

        val spokenTruck = "نقل 321 ط ظ ع"
        val (typeTruck, plateTruck) = VehicleType.extractFromSpeech(spokenTruck)
        assertEquals(VehicleType.TRUCK, typeTruck)
        assertEquals("321 ط ظ ع", plateTruck)
    }

    @Test
    fun testFlexibleSpeechWithFillerWords() {
        val (type1, plate1) = VehicleType.extractFromSpeech("عربية ونيت رقم 555")
        assertEquals(VehicleType.PICKUP, type1)
        assertEquals("555", plate1)

        val (type2, plate2) = VehicleType.extractFromSpeech("123 أ ب ج تاكسي")
        assertEquals(VehicleType.TAXI, type2)
        assertEquals("123 أ ب ج", plate2)
    }

    @Test
    fun testVehicleTypeFromArabicName() {
        assertEquals(VehicleType.PICKUP, VehicleType.fromArabicName("ونيت"))
        assertEquals(VehicleType.PICKUP, VehicleType.fromArabicName("دبابة"))
        assertEquals(VehicleType.TAXI, VehicleType.fromArabicName("تاكسي"))
        assertEquals(VehicleType.MICROBUS, VehicleType.fromArabicName("ميكروباص"))
        assertEquals(VehicleType.TRUCK, VehicleType.fromArabicName("نقل"))
    }
}
