<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/24f175fe-360e-42f5-9f75-e56c5ee4aa30

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## تعديلات إدارة الشوارع ومفاتيح API
- تمت إضافة شاشة «الشوارع» لتسجيل اسم الشارع والحي، وحفظ إحداثيات البداية والنهاية، وفتح الشارع من البطاقة على خرائط Google.
- تمت إضافة نافذة إعدادات لإدخال مفاتيح Gemini وDeepgram داخل التطبيق. مفتاح Gemini المحفوظ يستخدمه محلل اللوحات بدل مفتاح البناء عند توفره.
- ملاحظة مهمة: شاشة الشوارع تحفظ المواقع عند الضغط على بدء/إيقاف؛ لا يوجد تتبع GPS مستمر أثناء السير في هذا الإصدار. كما أن حفظ مفتاح Deepgram موجود، لكن رفع الصوت إلى Deepgram وتحويله لنص، واتصال Gemini Live الصوتي المباشر، يحتاجان تنفيذًا واختبارًا منفصلين ولم يُعتبرا مكتملين في هذه النسخة.
