package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlateViewModel
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.RecordScreen
import com.example.ui.screens.WatchlistScreen
import com.example.ui.screens.StreetsScreen
import com.example.ui.theme.AlertRed
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: PlateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PlateRadarApp(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlateRadarApp(viewModel: PlateViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val recordedCount by viewModel.recordedCount.collectAsState()
    val matchedCount by viewModel.matchedCount.collectAsState()
    val watchlistCount by viewModel.watchlistCount.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var showHelpDialog by remember { mutableStateOf(false) }
    var showApiDialog by remember { mutableStateOf(false) }
    val appContext = androidx.compose.ui.platform.LocalContext.current
    var geminiKey by remember { mutableStateOf(appContext.getSharedPreferences("ai_api_settings", 0).getString("gemini_api_key", "") ?: "") }
    var deepgramKey by remember { mutableStateOf(appContext.getSharedPreferences("ai_api_settings", 0).getString("deepgram_api_key", "") ?: "") }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Radar,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Text(
                            text = "راصد اللوحات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showApiDialog = true }, modifier = Modifier.testTag("api_settings_btn")) {
                        Icon(imageVector = Icons.Default.Key, contentDescription = "إعدادات مفاتيح API", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(
                        onClick = { showHelpDialog = true },
                        modifier = Modifier.testTag("app_help_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "دليل الاستخدام",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                // Tab 0: Voice & Scanner
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "الرصد الصوتي"
                        )
                    },
                    label = { Text("الرصد الصوتي", fontSize = 12.sp) },
                    modifier = Modifier.testTag("nav_tab_scan")
                )

                // Tab 1: History & Export
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        if (recordedCount > 0) {
                            BadgedBox(
                                badge = {
                                    Badge(
                                        containerColor = if (matchedCount > 0) AlertRed else MaterialTheme.colorScheme.primary
                                    ) {
                                        Text(recordedCount.toString())
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "سجل اللوحات"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "سجل اللوحات"
                            )
                        }
                    },
                    label = { Text("سجل اللوحات", fontSize = 12.sp) },
                    modifier = Modifier.testTag("nav_tab_history")
                )

                // Tab 2: Watchlist & Excel
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        if (watchlistCount > 0) {
                            BadgedBox(
                                badge = {
                                    Badge(containerColor = MaterialTheme.colorScheme.secondary) {
                                        Text(watchlistCount.toString())
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = "قائمة المراقبة"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.TableChart,
                                contentDescription = "قائمة المراقبة"
                            )
                        }
                    },
                    label = { Text("قائمة المراقبة", fontSize = 12.sp) },
                    modifier = Modifier.testTag("nav_tab_watchlist")
                )
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { viewModel.selectTab(3) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "الشوارع") },
                    label = { Text("الشوارع", fontSize = 12.sp) },
                    modifier = Modifier.testTag("nav_tab_streets")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> RecordScreen(viewModel = viewModel)
                1 -> HistoryScreen(viewModel = viewModel)
                2 -> WatchlistScreen(viewModel = viewModel)
                3 -> StreetsScreen()
            }
        }
    }

    if (showApiDialog) {
        AlertDialog(
            onDismissRequest = { showApiDialog = false },
            title = { Text("إعدادات مفاتيح API") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("أدخل المفاتيح داخل التطبيق. يتم حفظها محليًا على هذا الجهاز.", fontSize = 13.sp)
                    OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, label = { Text("Gemini API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                    OutlinedTextField(value = deepgramKey, onValueChange = { deepgramKey = it }, label = { Text("Deepgram API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    appContext.getSharedPreferences("ai_api_settings", 0).edit()
                        .putString("gemini_api_key", geminiKey.trim())
                        .putString("deepgram_api_key", deepgramKey.trim())
                        .apply()
                    showApiDialog = false
                    snackbarHostState.currentSnackbarData?.dismiss()
                }) { Text("حفظ المفاتيح") }
            },
            dismissButton = { TextButton(onClick = { showApiDialog = false }) { Text("إلغاء") } }
        )
    }

    // Help Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("دليل استخدام راصد اللوحات")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "١. الرصد الصوتي وتسجيل الموقع:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "اضغط على زر الميكروفون وتحدث برقم اللوحة ونوعها (مثال: 'ونيت 123 أ ب ج' أو 'تاكسي 456'). يقوم التطبيق تلقائياً بالتقاط إحداثيات GPS وحفظ السجل.",
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "٢. مطابقة اللوحات بقائمة إكسل:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "يمكنك من شاشة 'قائمة المراقبة' استيراد ملف إكسل أو CSV يحوي لوحات المراقبة. عند نطق أو إدخال أي لوحة مطابقة، يطلق التطبيق تنبيهاً فورياً باللون الأحمر مع الاهتزاز.",
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "٣. تصدير السجل إلى ملف إكسل:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "من شاشة 'سجل اللوحات'، اضغط على زر 'تصدير إكسل' لحفظ أو مشاركة السجل كاملاً بملف CSV متوافق 100% مع Microsoft Excel ومتضمناً الموقع الجغرافي وروابط خرائط جوجل.",
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "٤. تصنيف المركبات:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "يدعم التطبيق تصنيفات المركبات المطلوبة: ونيت (دبابة)، تاكسي، ميكروباص، نقل (شاحنة)، وملاكي.",
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("فهمت ذلك")
                }
            }
        )
    }
}
