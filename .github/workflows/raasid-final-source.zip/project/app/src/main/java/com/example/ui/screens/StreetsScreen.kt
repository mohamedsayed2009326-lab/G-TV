package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.LocationData
import com.example.data.LocationService
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private data class StreetSegment(
    val name: String,
    val neighborhood: String,
    val startLat: Double?,
    val startLon: Double?,
    val endLat: Double?,
    val endLon: Double?,
    val startedAt: Long,
    val endedAt: Long?
)

@Composable
fun StreetsScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("street_records", 0) }
    val locationService = remember { LocationService(context) }
    val scope = rememberCoroutineScope()
    val streets = remember { mutableStateListOf<StreetSegment>().apply { addAll(loadStreets(prefs.getString("items", "[]") ?: "[]")) } }
    var streetName by remember { mutableStateOf("") }
    var neighborhood by remember { mutableStateOf("") }
    var activeIndex by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("أدخل اسم الشارع والحي، ثم ابدأ التسجيل") }
    var hasLocationPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        hasLocationPermission = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        message = if (hasLocationPermission) "تم السماح بالموقع" else "يلزم السماح بالموقع لتسجيل بداية ونهاية الشارع"
    }

    fun persist() {
        val arr = JSONArray()
        streets.forEach { s -> arr.put(JSONObject().apply {
            put("name", s.name); put("neighborhood", s.neighborhood)
            if (s.startLat != null) put("startLat", s.startLat)
            if (s.startLon != null) put("startLon", s.startLon)
            if (s.endLat != null) put("endLat", s.endLat)
            if (s.endLon != null) put("endLon", s.endLon)
            put("startedAt", s.startedAt); if (s.endedAt != null) put("endedAt", s.endedAt)
        }) }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    suspend fun currentLocation(): LocationData? = if (hasLocationPermission) locationService.getCurrentLocation() else null

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("تسجيل الشوارع", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("كل شارع له بداية ونهاية مستقلة، ويمكن فتح موقعه بالضغط على بطاقته.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(value = streetName, onValueChange = { streetName = it }, label = { Text("اسم الشارع (مثال: الشزري 1)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = neighborhood, onValueChange = { neighborhood = it }, label = { Text("الحي (مثال: حي الرمال)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text(message, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            if (activeIndex == null) {
                Button(onClick = {
                    if (!hasLocationPermission) {
                        permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    } else if (streetName.isBlank()) {
                        message = "اكتب اسم الشارع أولًا"
                    } else {
                        scope.launch {
                            val loc = currentLocation()
                            streets.add(0, StreetSegment(streetName.trim(), neighborhood.trim(), loc?.latitude, loc?.longitude, null, null, System.currentTimeMillis(), null))
                            activeIndex = 0
                            persist()
                            message = if (loc != null) "بدأ تسجيل ${streetName.trim()} وتم حفظ موقع البداية" else "بدأ التسجيل، لكن تعذر تحديد GPS؛ تحقق من تشغيل الموقع"
                            streetName = ""
                            neighborhood = ""
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null); Spacer(Modifier.padding(3.dp)); Text("بدء تسجيل الشارع")
                }
            } else {
                Button(onClick = {
                    scope.launch {
                        val idx = activeIndex
                        val loc = currentLocation()
                        if (idx != null && idx in streets.indices) {
                            streets[idx] = streets[idx].copy(endLat = loc?.latitude, endLon = loc?.longitude, endedAt = System.currentTimeMillis())
                            persist()
                            activeIndex = null
                            message = "تم إيقاف الشارع وحفظ موقع النهاية. اكتب اسم الشارع التالي لبدء مسار جديد، أو أنهِ الجولة."
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.StopCircle, contentDescription = null); Spacer(Modifier.padding(3.dp)); Text("إيقاف الشارع وحفظ النهاية")
                }
            }
            if (streets.isNotEmpty()) {
                OutlinedButton(onClick = { if (activeIndex == null) message = "انتهت الجولة. تم حفظ الشوارع المسجلة على الجهاز." else message = "أوقف الشارع الحالي أولًا لحفظ نقطة النهاية." }, modifier = Modifier.fillMaxWidth()) { Text("إنهاء الجولة") }
            }
        }
        item { Text("الشوارع المسجلة (${streets.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }
        items(streets.indices.toList(), key = { i -> "${streets[i].startedAt}_$i" }) { i ->
            val street = streets[i]
            Card(modifier = Modifier.fillMaxWidth().clickable {
                val lat = street.startLat ?: street.endLat
                val lon = street.startLon ?: street.endLon
                if (lat != null && lon != null) {
                    val uri = if (street.endLat != null && street.endLon != null) Uri.parse("https://www.google.com/maps/dir/$lat,$lon/${street.endLat},${street.endLon}") else Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(street.name)})")
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                } else message = "لا يوجد موقع محفوظ لهذا الشارع؛ تحقق من إذن GPS"
            }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Map, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("${street.name} — ${street.neighborhood.ifBlank { "الحي غير محدد" }}", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    }
                    Text(if (street.endedAt == null) "التسجيل جارٍ" else "تم حفظ البداية والنهاية", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Text("اضغط لفتح الموقع على الخريطة", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

private fun loadStreets(json: String): List<StreetSegment> = try {
    val arr = JSONArray(json)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        StreetSegment(o.optString("name"), o.optString("neighborhood"), if (o.has("startLat")) o.optDouble("startLat") else null, if (o.has("startLon")) o.optDouble("startLon") else null, if (o.has("endLat")) o.optDouble("endLat") else null, if (o.has("endLon")) o.optDouble("endLon") else null, o.optLong("startedAt"), if (o.has("endedAt")) o.optLong("endedAt") else null)
    }
} catch (_: Exception) { emptyList() }
